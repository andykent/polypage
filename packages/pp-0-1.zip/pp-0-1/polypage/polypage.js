jQuery.polypage = {
	
	states: null, 
	
	init: function(defaults){
		this.buildOptionsBar();
		this.setStartValues(defaults);
		this.refresh();
	},
	
	setStartValues: function(initValues){
		if(initValues) {
			for(var i in initValues)
				this.setState(initValues[i],true);
		};
		var hashValues = window.location.hash.replace(/^#/,'').split(/_and_/);
		for(var i in hashValues)
			this.setState(hashValues[i],true);
	},
	
	findStates: function(){
		var el = this.findAll();
		var self = this;
		this.states = {};
		el.each(function() {
			var s = self.extractDataFromClassName(jQuery(this).attr('class'));
			var states = s.split(/_?not_|_or_|_and_/);
			for(var state in states)
				if(self.states[states[state]]==undefined && states[state]!='' ) self.states[states[state]]=false;
		});
		return this.states;
	},
	
	extractDataFromClassName: function(className){
		var classes = className.split(' ');
		for(var i in classes)
			if(classes[i].match(/pp_/)) return classes[i].replace(/pp_/,'');
		return '';
	},
	
	findAll: function(){
		return jQuery("*[@class~='pp_']");
	},
	
	refresh: function(){
		var self = this;
		this.findAll().each(function(){
			self.evaluateNode(this);
		});
	},
	
	evaluateNode: function(node){
		var on = this.evaluate(this.extractDataFromClassName(jQuery(node).attr('class')));
		if(on) jQuery(node).show();
		else jQuery(node).hide();
		return on;
	},
	
	evaluate: function(input){
		var str = input
			.replace(/^pp_/gi,'')
			.replace(/_?not_/gi,' !')
			.replace(/_and_/gi,' && ')
			.replace(/_or_/gi,' || ')
			.replace(/([a-z_]+)/gi,"this.states['$1']");
		return eval(str);
	},
	
	setState: function(state,val){
		this.states[state] = val ? true : false;
		jQuery('#pp_state_switch_'+state).toggleClass('active');
		this.refresh();
	},
	
	buildOptionsBar: function(){
		this.findStates();
		var self=this;
		jQuery('body').append('<div id="pp_options"><ul></ul></div>');
		for(var s in this.states){
			var state = s;
			var val = this.states[state];
			jQuery('#pp_options ul').append('<li><a href="#'+state+'" id="pp_state_switch_'+state+'">'+state.replace(/_/,' ')+'</a></li>');
			// show hide options
			
			// switch event
			jQuery('#pp_state_switch_'+state)
				.click(function() {
					var state = jQuery(this).attr('id').replace('pp_state_switch_','');
					self.setState(state,!self.states[state]);
					return false;
				});
		};
	},
	
};